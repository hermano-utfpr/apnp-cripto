#!/usr/bin/perl

use strict;

my $srv = "alice";

system("tar -xzf /opt/$srv/opt/diversos.tar.gz -C /root/");
system("chmod 755 /opt/$srv/usr/bin/*");
system("mv /opt/$srv/usr/bin/* /usr/bin/");

