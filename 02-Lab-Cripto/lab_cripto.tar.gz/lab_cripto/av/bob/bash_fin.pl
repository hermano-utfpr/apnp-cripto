#!/usr/bin/perl

use strict;

my $srv = "bob";

system("chmod 755 /opt/$srv/usr/bin/*");
system("mv /opt/$srv/usr/bin/* /usr/bin/");


