#!/usr/bin/perl

sub catch_hostname {
   my $hostname = qx/hostname/;
   chomp ($hostname);
   return $hostname;
}

sub install_pkg {
   my $pkg = shift;
   system ("dpkg --install --skip-same-version /opt/dpkg/$pkg/*.deb 2> /dev/null");
   system ("rm -Rf /opt/dpkg/$pkg/ 2> /dev/null"); 
}

